#include <iostream>
#include <SFML/Graphics.hpp>
using namespace std;

int main() {
	Texture T1;
	Sprite background;
	T1.loadFromFile("images/background.png");
	background.setTexture(T1);
	sf::RenderWindow
		window(sf::VideoMode(200, 200), "SFML WORKS!");
	sf::CircleShape shape(100.f);
	shape.setFillColor(sf::Color::Green);
	while (window.isOpen()) {
		sf::Event event;
		while (window.pollEvent(event)) {
			if (event.type == sf::Event::Closed)
				window.close();
		}
		if (Keyboard::isKeyPressed(Keyboard::Left))
			shape.move(-10, 0, 0, 0);
		if (Keyboard::isKeyPressed(Keyboard::Right))
			shape.move(10, 0, 0, 0);
		window.clear();
		window.draw(shape);
		window.display();
	}
	return 0;
}